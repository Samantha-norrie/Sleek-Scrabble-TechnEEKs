

var twoLetterWords = ["aa", "ab", "ad", "ae", "ag", "ah", "ai",
"al", "am", "an", "ar", "as", "at", "aw", "ax", "ay", "ba", "be",
"bi", "bo", "by", "de", "do", "ed", "ef", "eh", "el", "em", "en",
"er", "es", "et", "ex", "fa", "fe", "go", "ha, "he", "hi", "hm",
"ho", "id", "if", "in", "is", "it", "jo", "ka", "ki", "la", "li",
"lo", "ma", "me", "mi", "mm", "mo", "mu", "my", "na", "ne", "no", 
"nu", "od", "oe", "of", "oh", "oi", "om", "on", "op", "or", "os",
"ow", "ox", "oy", "pa", "pe", "pi", "qi", "re", "sh", "si", "so",
"ta", "ti", "to", "uh", "um", "un", "up","us", "ut", "we", "wo", 
"xi", "xu", "ya", "ye", "yo", "za"]
var desiredLetter;
var userName;
function openSettings () {
	document.getElementById('settings').classList.toggle("settings-open");
	clearName();
}



function changeName() {
	if(userName = document.getElementById("name-input").value == ""){
		userName = "friend";
	}else {
		userName = document.getElementById("name-input").value;
	}
	

	saveName();
	getGreeting();
}

function getGreeting() {
	document.getElementById('greeting').innerHTML = `Hello`;
}

function clearName() {
	document.getElementById("name-input").value = "";
}


document.getElementById("name-form").addEventListener('submit', function(e) {
	e.preventDefault();

	getGreeting();
	clearName();
});
